﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class blockaMap : MonoBehaviour
{
    public static bool[] cubes;
}
