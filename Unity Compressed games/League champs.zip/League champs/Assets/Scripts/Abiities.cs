﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Abiities : MonoBehaviour
{
    //this code will show the abilities cooldown using a slider shade, ,
    // Start is called before the first frame update
    public int QCooldow;
    public int CurrentQCooldown;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
