﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Residents : MonoBehaviour
{
    // Start is called before the first frame update
    private void Awake()
    {
        RaycastHit hit;
        Vector3 pos = new Vector3(0,0,0);
        if(Physics.Raycast(transform.position,Vector3.down,out hit)){
            pos = hit.point;
        }
        transform.position = pos;
        StartCoroutine(timer());
    }
    IEnumerator timer()
    {
        yield return new WaitForSeconds(1f);
        Destroy(this.gameObject);
    }
}
