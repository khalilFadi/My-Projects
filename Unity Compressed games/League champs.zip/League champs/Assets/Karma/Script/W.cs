﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class W : MonoBehaviour
{
    public float maxDistanec;
    public GameObject cube;
    public GameObject cylinde;
    public GameObject connection;
    public float distance;
    // Start is called before the first frame update
    void Start()
    {
        
        cylinde.transform.Rotate(0, 5, 0);
    }
    public Vector3 friend;
    public bool thereisafriend = false;
    bool Wison = false;
    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.W))
        {
            Wison = !Wison;

        }

        if (Wison)
        {
            RaycastHit hit;
            Ray r = Camera.main.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(r, out hit, Mathf.Infinity) && Input.GetMouseButtonDown(1))
            {
                //9 for friednd
                if (hit.transform.gameObject.layer == 10)
                {
                    distance = Vector3.Distance(transform.position, hit.transform.position);
                    if (distance <= maxDistanec)
                    {
                        thereisafriend = true;
                        friend = hit.transform.position;
                        GameObject g = Instantiate(connection);
                        g.transform.SetParent(hit.transform);
                        cylinde = hit.transform.GetChild(0).gameObject;
                        cylinde.transform.Rotate(0, 5, 0);
                        cylinde.transform.localScale = new Vector3(1, distance, 1);
                        StartCoroutine(connect());
                    }

                }
                Wison = false;
            }
        }
        if (thereisafriend)
        {
            cylinde.transform.position = new Vector3(
                (transform.position.x + friend.x) / 2f,
                (transform.position.y + friend.y) / 2f,
                (transform.position.z + friend.z) / 2f
                );
            cube = cylinde.transform.parent.gameObject;
            cylinde.transform.localScale = new Vector3(0.5f, distance, 0.5f);
            cube.transform.LookAt(transform.position);
            distance = Vector3.Distance(transform.position, friend) / 2;
            if (distance > maxDistanec)
            {
                thereisafriend = false;
                Destroy(cylinde);
            }
            //Debug.DrawRay(transform.position, (transform.position - friend) * -1, Color.red, 100);
        }

    }
    IEnumerator connect()
    {
        cylinde.transform.position = new Vector3(
                (transform.position.x + friend.x) / 2f,
                (transform.position.y + friend.y) / 2f,
                (transform.position.z + friend.z) / 2f
                );
        cube = cylinde.transform.parent.gameObject;
        cylinde.transform.localScale = new Vector3(0.5f, distance, 0.5f);
        cube.transform.LookAt(transform.position);
        distance = Vector3.Distance(transform.position, friend) / 2;
        if (distance > maxDistanec)
        {
            thereisafriend = false;
            Destroy(cylinde);
        }
        yield return new WaitForSeconds(3f);
        if(distance <= maxDistanec)
        {
            StopCoroutine("connect");
        }
        thereisafriend = false;
        this.gameObject.GetComponent<PlayerHealth>().health += 3;
        Destroy(cylinde);
    }
}
